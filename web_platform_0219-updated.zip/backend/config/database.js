const { runHtml2CanvasScript } = require('../data/util/fileDelete');

const connectDatabase = () => {
    runHtml2CanvasScript();
}

module.exports = connectDatabase;