import { atom } from 'recoil';

export const rankingLayoutIdAtom = atom({
  key: 'ranking_layout_id',
  default: 'ranking_developer',
});
