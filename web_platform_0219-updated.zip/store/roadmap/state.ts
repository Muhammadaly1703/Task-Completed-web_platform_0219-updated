import { atom } from 'recoil';

export const roadmapModalAtom = atom({
  key: 'roadmap_modal',
  default: false,
});
